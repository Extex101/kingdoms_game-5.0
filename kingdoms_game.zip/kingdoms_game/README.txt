Persistent Kingdoms GameMode [kingdoms_game]
=============================
The main subgame for the server "Persistent Kingdoms"
========================================

To use this subgame with the Minetest engine, insert this repository as
	/games/kingdoms_game

The Minetest engine can be found in:
	https://github.com/minetest/minetest/