CTF PvP Engine
==============

A highly modular framework for the Minetest game engine, in order to allow
the development of Capture the Flag / City vs City games. Good for any
sort of game where players can join teams - flags are optional, everything
is highly configurable.

Licenses
========

Created by: [rubenwardy](http://rubenwardy.com/).  
Copyright (c) 2013 - 2015  
**Code:** LGPL 2.1 or later.  
**Textures:** CC-BY-SA 3.0

ctf_flag/sounds/trumpet* by tobyk, license: CC-BY 3.0
from: http://freesound.org/people/tobyk/sounds/26198/

Documentation
=============

See the doc_* files, starting with doc_project_overview.md
