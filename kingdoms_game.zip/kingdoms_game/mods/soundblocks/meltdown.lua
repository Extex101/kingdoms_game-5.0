minetest.register_craft({
	output = "default:gold_ingot 5",
	type = "cooking",
	cooktime = 14,
	recipe = "soundblocks:trumpet"
})
minetest.register_craft({
	output = "default:gold_ingot 5",
	type = "cooking",
	cooktime = 14,
	recipe = "soundblocks:fanfare"
})
minetest.register_craft({
	output = "default:gold_ingot 5",
	type = "cooking",
	cooktime = 14,
	recipe = "soundblocks:bell_gold"
})
minetest.register_craft({
	output = "default:steel_ingot 5",
	type = "cooking",
	cooktime = 14,
	recipe = "soundblocks:bell"
})