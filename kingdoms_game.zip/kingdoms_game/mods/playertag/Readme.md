This mod hides the existing tags, and adds entity based tags that are only as visible as the player.

Some code taken from gauges (CC0 1.0) https://forum.minetest.net/viewtopic.php?t=10250
And also some code and textures from npcf (LGPL for code, WTFPL for textures) https://forum.minetest.net/viewtopic.php?t=7321
My part of the code is WTFPL.