# Email

Created by rubenwardy.

License: WTFPL.

## Usage

Send an email:

* /mail username message to send

View inbox:

* /inbox
* /inbox text

No formspec commands (good for IRC):

* /mail username message to send
* /inbox text
* /inbox clear
