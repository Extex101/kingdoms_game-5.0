# knockout
Adds a knockout system to minetest.
Once a player is knocked out, (s)he can be picked up by other players and moved around.
To pick up a player, right-click them once they are knocked out.
To drop a player, jump.
While a player is knocked out, they cannot move, talk, or run /killme.
They are also annoyed by a persistant formspec telling them how long they will be knocked out for.
