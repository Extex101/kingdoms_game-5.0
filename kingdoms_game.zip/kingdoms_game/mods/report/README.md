# Report

Allows players to report things to admins and online moderators.

Suppose `player`, `griefer` and `moderator` are online players.  
`player` runs this command: `/report griefer is griefing`  
`moderator` sees: `-!- player reported: griefer is griefing`  
The Admin (named in "name") is mailed via chatplus: `<player1> Report: player2 is griefing (mods online: player3)`

License: WTFPL  
Depends: chatplus.

