Minetest 0.4 mod: bandages
=========================

License of source code:
-----------------------
Andrey's mod for minetest

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-2.1.html


Bandages can be used to heal other players, but not yourself.
