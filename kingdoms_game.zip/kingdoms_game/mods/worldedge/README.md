worldedge
=========

A Minetest Mod that teleports you to the other side of the map when you reach its edge.
This gives the illusion that that world is round and you can walk all the way around.

You can change the worlds edge by changing the first variable in init.lua
	local edge = 30000

License of code: DWYWPL

Written by Amaz
Modified by Don
