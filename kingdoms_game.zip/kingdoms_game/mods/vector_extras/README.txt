TODO:
— maybe make the explosion table function return a perlin explosion table
