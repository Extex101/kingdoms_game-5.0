# Inbox for Minetest

[![home](https://img.shields.io/badge/inbox-home-blue.svg?style=flat-square)](https://github.com/bas080/inbox/)
[![download](https://img.shields.io/github/tag/bas080/inbox.svg?style=flat-square&label=release)](https://github.com/bas080/inbox/archive/master.zip)
[![git](https://img.shields.io/badge/git-project-green.svg?style=flat-square)](https://github.com/bas080/inbox)
[![forum](https://img.shields.io/badge/minetest-mod-green.svg?style=flat-square)](http://forum.minetest.net/viewtopic.php?f=11&t=7040)
[![bower](https://img.shields.io/badge/bower-mod-green.svg?style=flat-square)](https://minetest-bower.herokuapp.com/mods/inbox)


## Description

Safely share nodes and items with your neighbours


## Project Resources

* [Home](https://github.com/bas080/inbox/)
* [Download](https://github.com/bas080/inbox/archive/master.zip)
* [Project](https://github.com/bas080/inbox)
* [Forum](http://forum.minetest.net/viewtopic.php?f=11&t=7040)
* [Bower](https://minetest-bower.herokuapp.com/mods/inbox)
